<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Timework extends Model
{
    protected $table = 'timeworks';
    protected $guarded = [];
    protected $primaryKey = 'id';
}
