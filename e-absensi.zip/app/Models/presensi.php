<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class presensi extends Model
{
    protected $table = 'presensis';
    protected $guarded = [];
    protected $primaryKey = 'id';


  
}