<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class pegawai extends Model
{
    //
    protected $connection = 'extrupack';
    protected $table = 'pegawais';
}
