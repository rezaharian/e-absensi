@extends('user.ly')

@section('content')
    <div class="container py-2 text-muted mb-5 pb-5">
        <div class="row justify-content-center mb-5">
            <div class="col-md-10">
                <div class="bg-white shadow rounded-4 p-3">
                    <h5 class="text-xs font-bold mb-3 text-center">Absensi Kehadiran</h5>

                    <!-- Alerts -->
                    @if (session('success'))
                        <div class="alert alert-success text-center rounded-lg">{{ session('success') }}</div>
                    @endif
                    @if (session('error'))
                        <div class="alert alert-danger text-center rounded-lg">{{ session('error') }}</div>
                    @endif

                    <form action="{{ route('attendance.checkin') }}" method="POST" enctype="multipart/form-data"
                        id="attendanceForm">
                        @csrf
                        <div class="row g-3">
                            <!-- Kolom 1 -->
                            <div class="m-0">
                                <input type="text" id="liveTime" name="time"
                                    class="form-control text-primary form-control-sm text-center"
                                    style="border: none; font-size: 1rem; font-weight: bold; background: transparent;"
                                    readonly>
                            </div>


                            <div class="row">
                                <div class="col-md-6">
                                    <!-- Jenis Absensi -->
                                    <div class="mb-3 mt-3">
                                        <label class="form-label fw-semibold d-block mb-2">Jenis Absensi</label>
                                        <div class="d-flex">
                                            <input type="radio" class="btn-check" name="type" id="checkIn"
                                                value="in" autocomplete="off" required>
                                            <label for="checkIn"
                                                style="
            flex:1;
            text-align:center;
            padding:0.6rem 1rem;
            border:1px solid #007bff;
            border-right:none; /* hilangkan border kanan */
            border-radius:1rem 0 0 1rem; /* ujung kiri bulat */
            background:transparent;
            color:#007bff;
            font-weight:600;
            cursor:pointer;
            transition: all 0.3s ease;
        ">
                                                Masuk
                                            </label>

                                            <input type="radio" class="btn-check" name="type" id="checkOut"
                                                value="out" autocomplete="off" required>
                                            <label for="checkOut"
                                                style="
            flex:1;
            text-align:center;
            padding:0.6rem 1rem;
            border:1px solid #007bff;
            border-radius:0 1rem 1rem 0; /* ujung kanan bulat */
            background:transparent;
            color:#007bff;
            font-weight:600;
            cursor:pointer;
            transition: all 0.3s ease;
        ">
                                                Pulang
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Map & Alamat -->
                                    <div class="mb-3">


                                        <div id="map" style="height:180px;border-radius:12px;overflow:hidden;"
                                            class="mb-2"></div>
                                        <textarea id="address" name="address" rows="2" readonly
                                            style="border:none; box-shadow:none; outline:none; resize:none;" class="form-control form-control-sm rounded-lg">Menentukan alamat anda...</textarea>
                                        <div class="alert text-center py-1 rounded-lg mb-2 small" id="radiusAlert">
                                            Mendeteksi
                                            lokasi anda...</div>
                                        <div class="d-flex justify-content-between small text-muted">
                                            <span>Lat: <span id="latText">-</span></span>
                                            <span>Lng: <span id="lngText">-</span></span>
                                        </div>
                                        <input type="hidden" name="latitude" id="latitude">
                                        <input type="hidden" name="longitude" id="longitude">
                                    </div>
                                </div>

                                <!-- Kolom 2: Selfie -->
                                <div class="border rounded-lg overflow-hidden mb-2"
                                    style="position: relative; height: 280px;">
                                    <video id="video" autoplay playsinline class="w-100 h-100 object-fit-cover"></video>
                                    <button type="button" id="captureBtn"
                                        class="btn btn-sm btn-primary position-absolute bottom-0 end-0 m-2 d-flex align-items-center justify-content-center"
                                        style="width:40px; height:40px; border-radius:50%;">
                                        <i class="fas fa-camera"></i>
                                    </button>

                                </div>
                                <canvas id="canvas" style="display:none;"></canvas>
                                <input type="hidden" name="photo" id="selfie">
                                <div id="preview" class="text-center small"></div>
                            </div>

                            <!-- Tombol Submit -->
                            <div class="mt-3">
                                <button type="submit" id="submitBtn"
                                    class="btn btn-success w-100 py-2 rounded-lg fw-semibold" disabled>
                                    Kirim Absensi
                                </button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        const officeLat = {{ $office->latitude }};
        const officeLng = {{ $office->longitude }};
        const allowedRadius = {{ $office->radius }};

        document.addEventListener("DOMContentLoaded", function() {
            const map = L.map('map').setView([officeLat, officeLng], 16);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(map);

            L.marker([officeLat, officeLng]).addTo(map).bindPopup("Kantor").openPopup();
            L.circle([officeLat, officeLng], {
                color: 'blue',
                fillColor: '#3f8efc',
                fillOpacity: 0.2,
                radius: allowedRadius
            }).addTo(map);

            let userMarker;
            const radiusAlert = document.getElementById('radiusAlert');
            const submitBtn = document.getElementById('submitBtn');
            const selfieInput = document.getElementById('selfie');
            const liveTime = document.getElementById('liveTime');
            const addressField = document.getElementById('address');

            function getDistanceFromLatLonInM(lat1, lon1, lat2, lon2) {
                const R = 6371000;
                const dLat = (lat2 - lat1) * Math.PI / 180;
                const dLon = (lon2 - lon1) * Math.PI / 180;
                const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2);
                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                return R * c;
            }

            function updateStatus(distance) {
                if (distance <= allowedRadius) {
                    radiusAlert.className = 'alert alert-success text-center py-1 rounded-lg mb-2 small';
                    radiusAlert.textContent = `Di dalam radius (${Math.round(distance)} m)`;
                    submitBtn.disabled = !selfieInput.value; // enable hanya jika selfie sudah diambil
                } else {
                    radiusAlert.className = 'alert alert-danger text-center py-1 rounded-lg mb-2 small';
                    radiusAlert.textContent =
                        `Di luar radius (${Math.round(distance)} m, batas ${allowedRadius} m)`;
                    submitBtn.disabled = true; // disable selalu di luar radius
                }
            }

            // Geolocation
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    const lat = pos.coords.latitude;
                    const lng = pos.coords.longitude;
                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;
                    document.getElementById('latText').textContent = lat.toFixed(6);
                    document.getElementById('lngText').textContent = lng.toFixed(6);

                    if (userMarker) map.removeLayer(userMarker);
                    userMarker = L.marker([lat, lng]).addTo(map).bindPopup("Lokasi Anda").openPopup();
                    map.setView([lat, lng], 18);

                    const distance = getDistanceFromLatLonInM(lat, lng, officeLat, officeLng);
                    updateStatus(distance);

                    // Reverse geocoding
                    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
                        .then(res => res.json())
                        .then(data => addressField.value = data.display_name || "Alamat tidak ditemukan");
                }, function() {
                    alert("Tidak bisa mendapatkan lokasi. Aktifkan GPS!");
                    radiusAlert.className = 'alert alert-warning text-center py-1 rounded-lg mb-2 small';
                    radiusAlert.textContent = 'Lokasi tidak terdeteksi.';
                    submitBtn.disabled = true;
                });
            }

            // Kamera selfie
            const video = document.getElementById('video');
            const canvas = document.getElementById('canvas');
            const captureBtn = document.getElementById('captureBtn');
            const preview = document.getElementById('preview');

            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                navigator.mediaDevices.getUserMedia({
                        video: true
                    })
                    .then(stream => video.srcObject = stream)
                    .catch(() => alert("Tidak bisa mengakses kamera!"));
            }

            captureBtn.addEventListener('click', function() {
                const context = canvas.getContext('2d');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                context.drawImage(video, 0, 0, canvas.width, canvas.height);

                // Overlay waktu & alamat
                context.fillStyle = "rgba(0,0,0,0.5)";
                context.fillRect(0, canvas.height - 50, canvas.width, 50);
                context.fillStyle = "#fff";
                context.font = "20px Arial";
                context.fillText(liveTime.value, 10, canvas.height - 30);
                context.fillText(addressField.value.substring(0, 40) + "...", 10, canvas.height - 10);

                const dataURL = canvas.toDataURL('image/png');
                selfieInput.value = dataURL;
                preview.innerHTML =
                    `<img src="${dataURL}" class="rounded shadow mt-2" style="width:100%;max-width:200px;" alt="Preview Selfie">`;

                // Enable tombol submit hanya jika di dalam radius
                const distance = getDistanceFromLatLonInM(
                    parseFloat(document.getElementById('latitude').value),
                    parseFloat(document.getElementById('longitude').value),
                    officeLat, officeLng
                );
                submitBtn.disabled = distance > allowedRadius;
            });

            // Live time update
            setInterval(() => {
                const now = new Date();
                liveTime.value =
                    `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
            }, 1000);

            // Efek hover/klik radio button
            const labels = document.querySelectorAll('.btn-check + label');
            labels.forEach(label => {
                const input = document.getElementById(label.htmlFor);
                label.addEventListener('mouseover', () => {
                    if (!input.checked) {
                        label.style.background = 'linear-gradient(135deg, #6fb1fc, #4364f7)';
                        label.style.color = '#fff';
                    }
                });
                label.addEventListener('mouseout', () => {
                    if (!input.checked) {
                        label.style.background = 'transparent';
                        label.style.color = '#007bff';
                    }
                });
                input.addEventListener('change', () => {
                    labels.forEach(l => {
                        const inp = document.getElementById(l.htmlFor);
                        if (inp.checked) {
                            l.style.background =
                                'linear-gradient(135deg, #6fb1fc, #4364f7)';
                            l.style.color = '#fff';
                        } else {
                            l.style.background = 'transparent';
                            l.style.color = '#007bff';
                        }
                    });
                });
            });
        });
    </script>

    <script>
        // Menambahkan efek klik/hover inline tanpa CSS tambahan
        const labels = document.querySelectorAll('.btn-check + label');
        labels.forEach(label => {
            const input = document.getElementById(label.htmlFor);
            label.addEventListener('mouseover', () => {
                if (!input.checked) {
                    label.style.background = 'linear-gradient(135deg, #6fb1fc, #4364f7)';
                    label.style.color = '#fff';
                }
            });
            label.addEventListener('mouseout', () => {
                if (!input.checked) {
                    label.style.background = 'transparent';
                    label.style.color = '#007bff';
                }
            });
            input.addEventListener('change', () => {
                labels.forEach(l => {
                    const inp = document.getElementById(l.htmlFor);
                    if (inp.checked) {
                        l.style.background = 'linear-gradient(135deg, #6fb1fc, #4364f7)';
                        l.style.color = '#fff';
                    } else {
                        l.style.background = 'transparent';
                        l.style.color = '#007bff';
                    }
                });
            });
        });
    </script>
@endsection
