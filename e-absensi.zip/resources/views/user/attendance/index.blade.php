@extends('user.ly')

@section('content')
    <div class="container mb-5 mt-2 pb-5 text-muted">

        {{-- Header --}}
        <div class="d-flex flex-wrap justify-content-start align-items-center mb-4">
            <h6 class="fw-bold mb-0">History Absensi</h6>

        </div>

        {{-- Filter --}}
        <form method="GET" action="{{ route('attendance.index') }}" class="d-flex flex-wrap align-items-center gap-2 mb-4">
            <div class="input-group shadow-sm" style="max-width: 400px;">
                <select name="tahun" class="form-select form-select-sm">
                    @for ($t = date('Y'); $t >= date('Y') - 5; $t--)
                        <option value="{{ $t }}" {{ $tahun == $t ? 'selected' : '' }}>
                            {{ $t }}
                        </option>
                    @endfor
                </select>
                <select name="bulan" class="form-select form-select-sm">
                    @for ($b = 1; $b <= 12; $b++)
                        <option value="{{ sprintf('%02d', $b) }}" {{ $bulan == sprintf('%02d', $b) ? 'selected' : '' }}>
                            {{ \Carbon\Carbon::create()->month($b)->translatedFormat('F') }}
                        </option>
                    @endfor
                </select>
                <button type="submit" class="btn btn-sm btn-secondary px-3">
                    <i class="bi bi-funnel"></i>
                </button>
            </div>
        </form>

        {{-- Alert --}}
        @if (session('success'))
            <div class="alert alert-success text-center rounded-pill shadow-sm small">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger text-center rounded-pill shadow-sm small">
                {{ session('error') }}
            </div>
        @endif

        {{-- Card List Absensi --}}
        <div class="row g-3">
            @forelse($presensis as $index => $p)
                <div class="col-12 ">
                    <div class="card shadow-sm border-0 rounded-5 h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            {{-- Foto Selfie --}}
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    @if ($p->photo)
                                        <img src="{{ asset('storage/' . $p->photo) }}" alt="Selfie"
                                            class="rounded-circle border shadow-sm"
                                            style="width:50px; height:50px; object-fit:cover;">
                                    @else
                                        <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center"
                                            style="width:50px; height:50px;">
                                            <i class="bi bi-person text-muted"></i>
                                        </div>
                                    @endif
                                </div>
                                <div>
                                    <h6 class="mb-1 fw-bold">
                                        {{ $p->tanggal ? \Carbon\Carbon::parse($p->tanggal)->translatedFormat('d F Y') : '-' }}
                                    </h6>
                                    <small class="text-muted">
                                        @if ($p->time)
                                            {{ \Carbon\Carbon::parse($p->time)->format('H:i:s') }} —
                                            <span class="{{ $p->type == 'in' ? 'text-success' : 'text-danger' }}">
                                                {{ $p->type == 'in' ? 'Check-In' : 'Check-Out' }}
                                            </span>
                                        @endif
                                    </small>

                                </div>
                            </div>

                            {{-- Detail Info --}}
                            <div class="text-end">
                                <div class="small">
                                    <span class="text-muted">Masuk:</span>
                                    <span class="fw-semibold">{{ $p->masuk ?? '-' }}</span>
                                </div>
                                <div class="small">
                                    <span class="text-muted">Keluar:</span>
                                    <span class="fw-semibold">{{ $p->keluar ?? '-' }}</span>
                                </div>
                                <td>
                                    @if ($p->id)
                                        <a href="{{ route('attendance.show', [$p->id, $p->tanggal, $p->type]) }}"
                                            class="btn btn-sm btn-outline-primary rounded-pill mt-2 px-3">
                                            <i class="bi bi-eye"></i>
                                            Detail
                                        </a>
                                    @endif
                                </td>

                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-muted py-5">
                    <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                    <p class="mb-0">Belum ada data absensi</p>
                </div>
            @endforelse
        </div>
    </div>
@endsection
