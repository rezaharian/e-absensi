<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<div class="container my-3 text-muted">
    <h6 class="mb-3 fw-bold">Menu Utama</h6>
    <div class="row g-3">

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-calendar-check"></i>
                </div>
                <p>Izin</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-success bg-opacity-10 text-success">
                    <i class="bi bi-clock-history"></i>
                </div>
                <p>Lembur</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-warning bg-opacity-10 text-warning">
                    <i class="bi bi-calendar3"></i>
                </div>
                <p>Shift</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-danger bg-opacity-10 text-danger">
                    <i class="bi bi-wallet2"></i>
                </div>
                <p>Rembuse</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-info bg-opacity-10 text-info">
                    <i class="bi bi-newspaper"></i>
                </div>
                <p>Berita</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-secondary bg-opacity-10 text-secondary">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <p>Slip Gaji</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-dark bg-opacity-10 text-dark">
                    <i class="bi bi-activity"></i>
                </div>
                <p>Aktifitas</p>
            </div>
        </div>

        <div class="col-3 col-md-3">
            <div class="menu-card">
                <div class="icon bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-megaphone"></i>
                </div>
                <p>Info</p>
            </div>
        </div>

    </div>
</div>

<style>
    .menu-card {
        background: #fff;
        border-radius: 16px;
        padding: 10px 5px;
        text-align: center;
        transition: 0.3s;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    .menu-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
    }

    .menu-card .icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 8px;
        font-size: 24px;
    }

    .menu-card p {
        margin: 0;
        font-size: 13px;
        font-weight: 600;
        color: #333;
    }
</style>
