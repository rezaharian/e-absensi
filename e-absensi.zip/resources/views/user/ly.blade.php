<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

    <!-- Poppins Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif !important;
            background-color: #f8f9fa;
            letter-spacing: 0.5px;
            /* buat sedikit unik */
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-weight: 700;
            /* lebih tebal untuk heading */
            letter-spacing: 1px;
            /* spacing sedikit lebih lebar */
        }

        /* Background biru melengkung di atas */
        .header-bg {
            position: relative;
            height: 300px;
            background:
                linear-gradient(rgb(0, 123, 255), rgba(1, 124, 255, 0.895)),
                url('/batik3.jpg') left/cover no-repeat;
            background-blend-mode: normal;
        }

        @media (max-width: 768px) {
            .header-bg {
                height: 280px;
                border-bottom-left-radius: 50% 40%;
                border-bottom-right-radius: 50% 40%;
            }
        }
    </style>
</head>

<body>
    <div class="header-bg">
        @include('user.nav')
        <div class="pb-5">
            @yield('content')
        </div>
        @include('user.menubawah')

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function updateJam() {
            let now = new Date();
            let jam = String(now.getHours()).padStart(2, '0');
            let menit = String(now.getMinutes()).padStart(2, '0');
            let detik = String(now.getSeconds()).padStart(2, '0');
            document.getElementById("jamSekarang").textContent = jam + ":" + menit + ":" + detik;
        }

        updateJam();
        setInterval(updateJam, 1000);
    </script>
</body>

</html>
