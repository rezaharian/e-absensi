

<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="align-items-center">

            
            <div class="row">
                <div class="col-7  d-flex align-items-center">
                    
                    <!-- Avatar default huruf awal -->
                    <div class="rounded-circle bg-light text-secondary d-flex align-items-center justify-content-center me-1"
                        style="width:50px; height:50px; font-size:24px; font-weight:600;">
                        <?php echo e(strtoupper(substr(Auth::user()->nama_asli, 0, 1))); ?>

                    </div>
                    

                    <!-- Info user -->
                    <div>
                        <?php
                            $nameParts = explode(' ', Auth::user()->nama_asli); // pecah per kata
                            $shortName = '';

                            foreach ($nameParts as $index => $part) {
                                if ($index < 2) {
                                    // dua kata pertama tampil penuh
                                    $shortName .= $part . ' ';
                                } else {
                                    // kata ke-3 dst hanya huruf pertama
                                    $shortName .= strtoupper(substr($part, 0, 1)) . ' ';
                                }
                            }

                            $shortName = trim($shortName); // hapus spasi akhir
                            $shortName = strtoupper($shortName); // ubah semua jadi kapital

                            // Batasi maksimal 13 karakter
                            if (strlen($shortName) > 13) {
                                $shortName = substr($shortName, 0, 13) . '...';
                            }
                        ?>

                        <h5 class="mb-0 fw-bold text-light" style="text-shadow: 2px 2px 6px rgba(0,0,0,0.5);">
                            <?php echo e($shortName); ?></h5>

                        <b class="mb-0 text-light" style="text-shadow: 2px 2px 6px rgba(0,0,0,0.5);">
                            <?php echo e(Auth::user()->jabatan); ?>

                            <br>
                            <?php echo e(strtoupper(Auth::user()->no_payroll)); ?>


                        </b>
                    </div>
                </div>
                <div class="col-5 d-flex align-items-center justify-content-start">

                    <span
                        style="
                        font-size: 2rem;
                        font-weight: 800;
                        color: #ffffff;
                        text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
                    ">
                        <span id="jamSekarang"></span>
                    </span>


                    

                </div>

            </div>

        </div>
    </div>
    <?php echo $__env->make('user.menukotak', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('user.menuutama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.ly', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\e-absensi\resources\views/user/dashboard.blade.php ENDPATH**/ ?>