

<?php $__env->startSection('content'); ?>
    <div class="container py-3">
        
        <div class="text-center mb-3">
            <h5 class="fw-bold mb-1"><i class="bi bi-person-badge"></i> Detail Absensi</h5>
            <small class="text-muted">Informasi absensi karyawan</small>
        </div>

        
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-3">

                
                <div class="d-flex align-items-center mb-3">
                    <img src="https://ui-avatars.com/api/?name=<?php echo e($attendance->user->name); ?>&background=0D8ABC&color=fff"
                        alt="Foto Profil" class="rounded-circle me-2" width="55" height="55">
                    <div>
                        <h6 class="mb-0 fw-bold"><?php echo e($attendance->user->nama_asli); ?></h6>
                        <small class="text-muted"><i class="bi bi-briefcase"></i>
                            <?php echo e($attendance->user->jabatan ?? 'Karyawan'); ?>

                        </small>
                    </div>
                </div>

                
                <ul class="list-group list-group-flush small mb-3">
                    <li class="list-group-item d-flex justify-content-between align-items-center px-2 py-2">
                        <span><i class="bi bi-fingerprint text-primary"></i> Jenis</span>
                        <span class="fw-semibold text-dark text-uppercase">
                            <?php echo e($attendance->type == 'in' ? 'Check-In' : 'Check-Out'); ?>

                        </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-2 py-2">
                        <span><i class="bi bi-calendar-event text-success"></i> Tanggal</span>
                        <span class="fw-semibold">
                            <?php echo e(\Carbon\Carbon::parse($attendance->time)->format('d M Y')); ?>

                        </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-2 py-2">
                        <span><i class="bi bi-clock text-warning"></i> Jam</span>
                        <span class="fw-semibold">
                            <?php echo e(\Carbon\Carbon::parse($attendance->time)->format('H:i')); ?>

                        </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-2 py-2">
                        <span><i class="bi bi-geo-alt text-danger"></i> Lokasi</span>
                        <small class="fw-semibold text-truncate" style="max-width: 200px;">
                            <?php echo e($attendance->address); ?>

                        </small>
                    </li>
                </ul>

                
                <div class="text-center">
                    <h6 class="fw-bold mb-2"><i class="bi bi-camera"></i> Foto Absensi</h6>
                    <img src="<?php echo e(asset('storage/' . $attendance->photo)); ?>" alt="Foto Absensi"
                        class="img-fluid rounded-3 shadow-sm border" style="max-height: 220px; object-fit: cover;">
                </div>

                
                <div class="mt-3 text-center">
                    <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.ly', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\e-absensi\resources\views/user/attendance/show.blade.php ENDPATH**/ ?>