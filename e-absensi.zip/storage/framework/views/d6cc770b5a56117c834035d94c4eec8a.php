<div class="info-presensi mt-5  text-muted">
    <div class="rounded-4 p-3 pb-1 mx-3"
        style="background-color: white; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
            border-bottom-left-radius: 2%; 
            border-bottom-right-radius: 2%;">

        <div class="row">
            <div class="col-6">
                <span>Reguler</span><br>
                <b>08:00 - 16:50</b><br>
                <small>Masuk : 08:00</small>
            </div>
            <div class="col-6">
                <span>
                    <span id="hariSekarang"><?php echo e(\Carbon\Carbon::now()->translatedFormat('l')); ?></span>,
                    <span class="fw-bold" id="jamSekarang"></span>
                </span><br>
                <b><?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?></b><br>
                <small>Pulang : 16:30</small>
            </div>



        </div>

        <hr>
        <div class="text-center mb-2">
            <b class="  " style="color: #00aaff;">Rekap absen bulan ini</b>
        </div>

        <div class="row text-center">
            <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col stat-box bg<?php echo e($loop->iteration); ?> shadow-sm " data-bs-toggle="modal"
                    data-bs-target="#modal<?php echo e($loop->iteration); ?>" style="cursor: pointer; transition: transform 0.2s;"
                    onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    <p class="mb-1 fw-semibold"><?php echo e($jenis == 'Mangkir' ? 'MK' : $jenis); ?></p>
                    <b class="fs-4"><?php echo e($data['jumlah']); ?></b>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="modal<?php echo e($loop->iteration); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content shadow-lg border-0 rounded-4">
                            <div class="modal-header bg-primary text-white rounded-top-4">
                                <h5 class="modal-title">Rincian <?php echo e($jenis); ?></h5>
                                <button type="button" class="btn-close btn-close-white"
                                    data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $data['tanggal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="bi bi-calendar-event me-2 text-primary"></i>
                                                <?php echo e($row['hari']); ?></span>
                                            <span class="fw-bold"><?php echo e($row['tgl']); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary rounded-pill px-4"
                                    data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle"></i> Tutup
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>






    </div>

    <style>
        .stat-box {
            padding: 1px;
            /* border-radius: 12px; */
            /* margin: 3px; */
            transition: 0.3s;
        }

        .stat-box:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .stat-box p {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
        }

        .stat-box b {
            font-size: 23px;
            font-weight: 600;
            color: #000000af;
        }

        /* Gradient dari bawah → atas (pekat → transparan) */
        .bg1 {
            background: linear-gradient(to top, rgba(0, 123, 255, 0.3), transparent);
            border-radius: 0 0 0 10px;
        }

        .bg2 {
            background: linear-gradient(to top, rgba(40, 167, 69, 0.3), transparent);
        }

        .bg3 {
            background: linear-gradient(to top, rgba(220, 53, 69, 0.3), transparent);
        }

        .bg4 {
            background: linear-gradient(to top, rgba(255, 193, 7, 0.3), transparent);
            border-radius: 0 0 10px 0;

        }

        .bg5 {
            background: linear-gradient(to top, rgba(7, 255, 44, 0.3), transparent);
            border-radius: 0 0 10px 0;

        }

        .bg6 {
            background: linear-gradient(to top, rgba(255, 7, 28, 0.3), transparent);
            border-radius: 0 0 10px 0;

        }
    </style>

</div>
<?php /**PATH P:\laravel12\e-absensi\resources\views/user/menukotak.blade.php ENDPATH**/ ?>