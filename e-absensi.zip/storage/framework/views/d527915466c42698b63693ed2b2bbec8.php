

<?php $__env->startSection('content'); ?>
    <div class="container mb-5 mt-2 pb-5 text-muted">

        
        <div class="d-flex flex-wrap justify-content-start align-items-center mb-4">
            <h6 class="fw-bold mb-0">History Absensi</h6>

        </div>

        
        <form method="GET" action="<?php echo e(route('attendance.index')); ?>" class="d-flex flex-wrap align-items-center gap-2 mb-4">
            <div class="input-group shadow-sm" style="max-width: 400px;">
                <select name="tahun" class="form-select form-select-sm">
                    <?php for($t = date('Y'); $t >= date('Y') - 5; $t--): ?>
                        <option value="<?php echo e($t); ?>" <?php echo e($tahun == $t ? 'selected' : ''); ?>>
                            <?php echo e($t); ?>

                        </option>
                    <?php endfor; ?>
                </select>
                <select name="bulan" class="form-select form-select-sm">
                    <?php for($b = 1; $b <= 12; $b++): ?>
                        <option value="<?php echo e(sprintf('%02d', $b)); ?>" <?php echo e($bulan == sprintf('%02d', $b) ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::create()->month($b)->translatedFormat('F')); ?>

                        </option>
                    <?php endfor; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-secondary px-3">
                    <i class="bi bi-funnel"></i>
                </button>
            </div>
        </form>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center rounded-pill shadow-sm small">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger text-center rounded-pill shadow-sm small">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <div class="row g-3">
            <?php $__empty_1 = true; $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 ">
                    <div class="card shadow-sm border-0 rounded-5 h-100">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <?php if($p->photo): ?>
                                        <img src="<?php echo e(asset('storage/' . $p->photo)); ?>" alt="Selfie"
                                            class="rounded-circle border shadow-sm"
                                            style="width:50px; height:50px; object-fit:cover;">
                                    <?php else: ?>
                                        <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center"
                                            style="width:50px; height:50px;">
                                            <i class="bi bi-person text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h6 class="mb-1 fw-bold">
                                        <?php echo e($p->tanggal ? \Carbon\Carbon::parse($p->tanggal)->translatedFormat('d F Y') : '-'); ?>

                                    </h6>
                                    <small class="text-muted">
                                        <?php if($p->time): ?>
                                            <?php echo e(\Carbon\Carbon::parse($p->time)->format('H:i:s')); ?> —
                                            <span class="<?php echo e($p->type == 'in' ? 'text-success' : 'text-danger'); ?>">
                                                <?php echo e($p->type == 'in' ? 'Check-In' : 'Check-Out'); ?>

                                            </span>
                                        <?php endif; ?>
                                    </small>

                                </div>
                            </div>

                            
                            <div class="text-end">
                                <div class="small">
                                    <span class="text-muted">Masuk:</span>
                                    <span class="fw-semibold"><?php echo e($p->masuk ?? '-'); ?></span>
                                </div>
                                <div class="small">
                                    <span class="text-muted">Keluar:</span>
                                    <span class="fw-semibold"><?php echo e($p->keluar ?? '-'); ?></span>
                                </div>
                                <td>
                                    <?php if($p->id): ?>
                                        <a href="<?php echo e(route('attendance.show', [$p->id, $p->tanggal, $p->type])); ?>"
                                            class="btn btn-sm btn-outline-primary rounded-pill mt-2 px-3">
                                            <i class="bi bi-eye"></i>
                                            Detail
                                        </a>
                                    <?php endif; ?>
                                </td>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-muted py-5">
                    <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                    <p class="mb-0">Belum ada data absensi</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.ly', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\e-absensi\resources\views/user/attendance/index.blade.php ENDPATH**/ ?>