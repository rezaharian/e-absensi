<div class="container py-4">
    <h4 class="mb-3">Absensi Online</h4>

    <div class="card p-3 shadow-sm">
        <form id="attendanceForm" method="POST" action="<?php echo e(route('attendance.checkin')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="latitude" id="latitude">
            <input type="hidden" name="longitude" id="longitude">

            <div class="mb-3 text-center">
                <video id="camera" autoplay playsinline class="border rounded w-100"
                    style="max-width: 300px;"></video>
                <canvas id="snapshot" class="d-none"></canvas>
                <input type="file" id="photo" name="photo" accept="image/*" capture="camera" class="d-none">
                <button type="button" id="takePhoto" class="btn btn-primary mt-2">📸 Ambil Selfie</button>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-success">✅ Check In</button>
            </div>
        </form>
    </div>

    <div id="message" class="alert mt-3 d-none"></div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const video = document.getElementById('camera');
        const canvas = document.getElementById('snapshot');
        const photoInput = document.getElementById('photo');
        const messageBox = document.getElementById('message');

        // ---- 1. Ambil lokasi user ----
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                document.getElementById('latitude').value = position.coords.latitude;
                document.getElementById('longitude').value = position.coords.longitude;
            }, function() {
                alert('Gagal mengambil lokasi. Pastikan GPS aktif.');
            });
        } else {
            alert('Browser tidak mendukung geolocation.');
        }

        // ---- 2. Aktifkan kamera ----
        navigator.mediaDevices.getUserMedia({
                video: true
            })
            .then(stream => {
                video.srcObject = stream;
            })
            .catch(err => {
                alert('Tidak bisa mengakses kamera: ' + err);
            });

        // ---- 3. Ambil foto ----
        document.getElementById('takePhoto').addEventListener('click', function() {
            const context = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            canvas.toBlob(blob => {
                const file = new File([blob], "selfie.jpg", {
                    type: "image/jpeg"
                });
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                photoInput.files = dataTransfer.files;
                alert('Foto berhasil diambil!');
            }, 'image/jpeg');
        });

        // ---- 4. Submit absensi ----
        document.getElementById('attendanceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch("<?php echo e(route('attendance.checkin')); ?>", {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    messageBox.classList.remove('d-none', 'alert-danger', 'alert-success');
                    if (data.message) {
                        messageBox.classList.add('alert-success');
                        messageBox.innerText = data.message;
                    } else {
                        messageBox.classList.add('alert-danger');
                        messageBox.innerText = 'Gagal absensi';
                    }
                })
                .catch(error => {
                    messageBox.classList.remove('d-none');
                    messageBox.classList.add('alert-danger');
                    messageBox.innerText = 'Terjadi kesalahan.';
                });
        });
    });
</script>
<?php /**PATH P:\laravel12\e-absensi\resources\views/user/absensi.blade.php ENDPATH**/ ?>