

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Selamat datang, Admin <?php echo e(Auth::user()->name); ?></h1>

        <!-- Tombol Logout -->
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-3">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">
                Logout
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.ly', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\e-absensi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>