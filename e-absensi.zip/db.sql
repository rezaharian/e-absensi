-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.41 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table e_absensi.attendances
DROP TABLE IF EXISTS `attendances`;
CREATE TABLE IF NOT EXISTS `attendances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `office_id` bigint unsigned NOT NULL,
  `type` enum('in','out') COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` timestamp NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendances_user_id_foreign` (`user_id`),
  KEY `attendances_office_id_foreign` (`office_id`),
  CONSTRAINT `attendances_office_id_foreign` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.attendances: ~7 rows (approximately)
DELETE FROM `attendances`;
INSERT INTO `attendances` (`id`, `user_id`, `office_id`, `type`, `time`, `address`, `latitude`, `longitude`, `photo`, `created_at`, `updated_at`) VALUES
	(14, 2, 1, 'in', '2025-08-26 04:41:36', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21627847, 106.97439913, 'selfies/selfie_1756183297.png', '2025-08-25 21:41:37', '2025-08-25 21:41:37'),
	(15, 2, 1, 'in', '2025-08-26 04:42:30', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21630811, 106.97439411, 'selfies/selfie_1756183351.png', '2025-08-25 21:42:31', '2025-08-25 21:42:31'),
	(16, 2, 1, 'in', '2025-08-26 05:02:50', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21619700, 106.97431360, 'selfies/selfie_1756184573.png', '2025-08-25 22:02:53', '2025-08-25 22:02:53'),
	(17, 2, 1, 'in', '2025-08-26 05:05:35', 'Gang Haji Jabar, Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21678300, 106.97431460, 'selfies/selfie_1756184740.png', '2025-08-25 22:05:40', '2025-08-25 22:05:40'),
	(18, 2, 1, 'in', '2025-08-26 05:26:05', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21612910, 106.97461780, 'selfies/selfie_1756186076.png', '2025-08-25 22:27:56', '2025-08-25 22:27:56'),
	(19, 2, 1, 'in', '2025-08-26 08:18:36', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21571470, 106.97429310, 'selfies/selfie_1756196324.png', '2025-08-26 08:18:44', '2025-08-26 08:18:44'),
	(20, 2, 1, 'in', '2025-08-26 08:23:54', 'Gang Haji Jabar, Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21686560, 106.97428940, 'selfies/selfie_1756196644.png', '2025-08-26 08:24:04', '2025-08-26 08:24:04'),
	(21, 2, 1, 'out', '2025-08-27 04:01:09', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21634300, 106.97445700, 'selfies/selfie_1756267272.png', '2025-08-27 04:01:12', '2025-08-27 04:01:12'),
	(22, 2, 1, 'in', '2025-08-27 04:03:43', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21634300, 106.97445700, 'selfies/selfie_1756267426.png', '2025-08-27 04:03:46', '2025-08-27 04:03:46'),
	(23, 2, 1, 'in', '2025-08-27 04:07:03', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21634300, 106.97445700, 'selfies/selfie_1756267626.png', '2025-08-27 04:07:06', '2025-08-27 04:07:06'),
	(24, 2, 1, 'in', '2025-08-27 04:07:03', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21634300, 106.97445700, 'selfies/selfie_1756267626.png', '2025-08-27 04:07:06', '2025-08-27 04:07:06'),
	(25, 2, 1, 'out', '2025-08-27 05:34:47', 'Rawa Pasung, Kalibaru, Bekasi, West Java, Java, 17133, Indonesia', -6.21613270, 106.97461900, 'selfies/selfie_1756272891.png', '2025-08-27 05:34:51', '2025-08-27 05:34:51');

-- Dumping structure for table e_absensi.cache
DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.cache: ~0 rows (approximately)
DELETE FROM `cache`;

-- Dumping structure for table e_absensi.cache_locks
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.cache_locks: ~0 rows (approximately)
DELETE FROM `cache_locks`;

-- Dumping structure for table e_absensi.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.failed_jobs: ~0 rows (approximately)
DELETE FROM `failed_jobs`;

-- Dumping structure for table e_absensi.jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.jobs: ~0 rows (approximately)
DELETE FROM `jobs`;

-- Dumping structure for table e_absensi.job_batches
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.job_batches: ~0 rows (approximately)
DELETE FROM `job_batches`;

-- Dumping structure for table e_absensi.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.migrations: ~0 rows (approximately)
DELETE FROM `migrations`;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1),
	(4, '2025_08_26_015405_create_offices_table', 1),
	(5, '2025_08_26_015415_create_attendances_table', 1);

-- Dumping structure for table e_absensi.offices
DROP TABLE IF EXISTS `offices`;
CREATE TABLE IF NOT EXISTS `offices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `radius` int NOT NULL DEFAULT '500',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.offices: ~1 rows (approximately)
DELETE FROM `offices`;
INSERT INTO `offices` (`id`, `name`, `latitude`, `longitude`, `radius`, `created_at`, `updated_at`) VALUES
	(1, 'PT Extrupack', -6.21627944, 106.97440472, 80, NULL, NULL);

-- Dumping structure for table e_absensi.password_reset_tokens
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.password_reset_tokens: ~0 rows (approximately)
DELETE FROM `password_reset_tokens`;

-- Dumping structure for table e_absensi.sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.sessions: ~2 rows (approximately)
DELETE FROM `sessions`;
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('hDTH8vwwA5plJJIvrdv9JCHDEY5mao2MkMhmE5Dd', 2, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoib3FlZGVoeTQ4ajVXT1laN0hacVhJa21rZ2t1S0ptMElhbmoyY254MyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly8zYzIwMjZiYjMyODEubmdyb2stZnJlZS5hcHAvYXR0ZW5kYW5jZS9pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjI7fQ==', 1756273705),
	('WuMOLe0GDNnRWldfyalfMDjvhnxwvXj4fsDK88oH', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNkI2QVVMUzRFY3pVWU9raU9IODJjVmFWdTdpMHZPT3A5cHdQbHV0ciI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC91c2VyIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9', 1756265525);

-- Dumping structure for table e_absensi.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table e_absensi.users: ~2 rows (approximately)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Test User', 'test@example.com', '2025-08-25 21:12:15', '$2y$12$xOtUO7Bqno97HEPj/UgYPecv7eLzFEwgPZt1iA3ePxWrJuGtx25Ba', 'user', 'eyNRukVpdR', '2025-08-25 21:12:15', '2025-08-25 21:12:15'),
	(2, 'reza HarIan saputra', 'reza@gmail.com', NULL, '$2y$12$bEBt2DZC1QrIQywxjdtOouB2thP4Crqv.mR1rqySfxJQGehPkDKtu', 'user', NULL, '2025-08-25 21:12:29', '2025-08-25 21:12:29');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
